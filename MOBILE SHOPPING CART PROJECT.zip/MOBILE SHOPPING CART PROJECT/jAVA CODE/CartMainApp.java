package edu.project;

import java.io.IOException;					
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.sql.SQLException;
import java.util.Scanner;
	
public class CartMainApp {
	
	private static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) throws SQLException, IOException {
		System.out.println("-*-*-*-*- Mobile Shopping Cart -*-*-*-*-");
		System.out.println("-----Choose the option-----");
		Scanner sc =new Scanner(System.in);
			
	
		System.out.println("1.Admin");
		System.out.println("2.User");
		//for admin
		int op=sc.nextInt();
		 
		switch(op) {
		case 1:
		System.out.println("-----Welcome to admin login!-----");
		System.out.println("Enter User Name:");
		String user=br.readLine();
		System.out.println("Enter Password:");
		String password=br.readLine();
		 
		 if(user.equals("admin") && (password.equals("admin123"))){

			 while(true) {		
		System.out.println("-----Select the option to perform-----");
		System.out.println("1.Display Products");
		System.out.println("2.Add New Products");
		System.out.println("3.Update Products");
		System.out.println("4.Delete Products");
		
		int choice=sc.nextInt();
		switch(choice) {
		case 1:
			JdbcOperations.displayRecords();
			break;
		case 2:
			JdbcOperations.insertRecords();
			break;
		case 3 :
			JdbcOperations.updateRecords();
			break;
		case 4 :
			JdbcOperations.deleteRecords();
			break;
		default :
			System.out.println("invalid choice");
		}
		System.out.println("Do you want to continue y/n");
		char ch=sc.next().toLowerCase().charAt(0);
		if (ch!='y') {
			System.out.println("Admin logout");
			break;
		}
			 }
		 }	 
		 else {
			 System.out.println("The admin id and password was incorrect! ");
		 }
           
		break;
			 
		 //user
		case 2:
			while(true) {
			System.out.println("Welcome to user login!");
			System.out.println("---Enter your choice---");
			System.out.println("1.New user ");
			System.out.println("2.User login ");
			int sel=Integer.parseInt(br.readLine());
			
			switch(sel) {
			case 1:
				JdbcOperations.insertNewUsers();
				break;
			
			case 2:
				JdbcOperations.userMethod();
				break;
			default:
				System.out.println("Invalid choice");
			}
					
		
		System.out.println("Do you want to redirect to the user login y/n");
		char ui=sc.next().toLowerCase().charAt(0);
		if(ui!='y') {
			System.out.println("Program is terminated!");
			break;
			
		}
			
		}
			
			break;
			
		 }
		
	
	}
}



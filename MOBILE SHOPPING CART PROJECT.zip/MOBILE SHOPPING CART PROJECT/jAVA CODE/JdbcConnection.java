package edu.project;	
import java.sql.Connection;			
import java.sql.DriverManager;

public class JdbcConnection {
	 static Connection con=null;
	public static Connection getConnection() {
		 String Driver="com.mysql.cj.jdbc.Driver";
		 String url="jdbc:mysql://localhost:3306/project";
		 String username="root";
		 String password="root";
		 try {
			 Class.forName(Driver);
			 con=DriverManager.getConnection(url,username,password);
			 
			 if(con==null) {
				 System.out.println("connection error");
			 }
			 }
		 catch(Exception e) {
				 e.printStackTrace();
			 }	 
		 
		return con;
		 
	 }
}


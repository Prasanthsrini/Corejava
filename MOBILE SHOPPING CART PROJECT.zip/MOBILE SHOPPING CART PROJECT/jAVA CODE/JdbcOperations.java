package edu.project;

import java.io.BufferedReader;										
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;





public class JdbcOperations {
	private static Connection cons;
	private static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	private static int productId;
	private static String productName;
	private static float productPrice;
	private static int productQuantity;
	private static int cartQuantity;
	private static int userId;
	private static String userName;
	private static String userPhone;
	private static String userPassword;
	private static PreparedStatement pst;
	private static ResultSet rs;
	public static int usersid;
	private static Scanner sc=new Scanner(System.in);
	

	// to display the record
	public static void displayRecords() throws SQLException{
		cons=JdbcConnection.getConnection();
		String sel="Select * from product";
		pst=cons.prepareStatement(sel);
		rs=pst.executeQuery();//result set 
		System.out.println("___________________________________________________");
		System.out.println("");
		System.out.println("pid\tpname\t\tpprice\t\tpquantity");
		System.out.println("___________________________________________________");
		System.out.println("");
		while(rs.next()) {
		System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getFloat(3)+"\t\t"+rs.getInt(4));
		System.out.println("");
		System.out.println("---------------------------------------------------");
		}			
		
	}
	//to insert the records
	public static void insertRecords() throws SQLException, IOException {
		cons = JdbcConnection.getConnection(); 
		System.out.println("Enter the product id");
		productId=Integer.parseInt(br.readLine());
		System.out.println("Enter the product name");
		productName=br.readLine();
		System.out.println("Enter the product price");
		productPrice=Float.parseFloat(br.readLine());
		System.out.println("Enter the product quantity");
		productQuantity=Integer.parseInt(br.readLine());
		
		//check pid exists or not
				String sel = "select * from product where pid=?";
				
				pst = cons.prepareStatement(sel);
				pst.setInt(1, productId);
				rs = pst.executeQuery(); //selection use executeQuery	
				//to check id exists or not
				if(!rs.next()) { //if record is not there then go for insert
					String ins = "insert into product values(?,?,?,?)";
					pst = cons.prepareStatement(ins);
					pst.setInt(1, productId);
					pst.setString(2, productName);
					pst.setFloat(3, productPrice);
					pst.setInt(4, productQuantity);
					int retval = pst.executeUpdate(); //for insert , update , delete use executeUpdate
					if(retval>0) {
						System.out.println("Record inserted");
						displayRecords();
			
					}else {
						System.out.println("Error occured");
					}
			}
				else {
					System.out.println(productId+" already exists ");
				}	
				
	}
	//to update the records
	public static void updateRecords()throws SQLException, IOException {

		System.out.println("-----Enter your choice to change-----");
		System.out.println("1.To change product Name ");
		System.out.println("2.To change product Price ");
		System.out.println("3.To change product Quantity");
		
		int option=sc.nextInt();
		switch(option) {
		//to change the product name
		case 1:
			cons = JdbcConnection.getConnection();
			System.out.println("Enter product ID:");
			productId=sc.nextInt();
			 String select="select * from product where pid=?";
			 pst=cons.prepareStatement(select);
			 pst.setInt(1, productId);
			 rs=pst.executeQuery();
			 if(rs.next()) {
				 System.out.println("Enter product Name to Change:");
				 productName=br.readLine();
				 
				 String update="update product set pname=? where pid=?";
				 pst=cons.prepareStatement(update);
				 pst.setString(1, productName);
				 pst.setInt(2, productId);
				 int retval=pst.executeUpdate();
				 if(retval>0) {
					 System.out.println("Successfully changed the Name ");
					 displayRecords();
				 }
				 else {
					 System.out.println("Updation Error!");
				 }
			 }
			 else
			 {
				 System.out.println("product ID was not Found in the database");
			 }
			 break;
			 //to change product price
		case 2:
			cons = JdbcConnection.getConnection();
			System.out.println("Enter product ID:");
			productId=sc.nextInt();
			 String select1="select * from product where pid=?";
			 pst=cons.prepareStatement(select1);
			 pst.setInt(1, productId);
			 rs=pst.executeQuery();
			 if(rs.next()) {
				 System.out.println("Enter product price to Change:");
				 productPrice=sc.nextFloat();
				 
				 String update="update product set pprice=? where pid=?";
				 pst=cons.prepareStatement(update);
				 pst.setFloat(1, productPrice);
				 pst.setInt(2, productId);
				 int retval=pst.executeUpdate();
				 if(retval>0) {
					 System.out.println("Successfully changed the product price");
					 displayRecords();
				 }else {
					 System.out.println("Updation Error!");
				 }
			 }else
			 {
				 System.out.println("product ID was not Found in the database");
			 }
			 break;
		case 3:
			cons = JdbcConnection.getConnection();
			System.out.println("Enter product ID:");
			productId=sc.nextInt();
			 String select11="select * from product where pid=?";
			 pst=cons.prepareStatement(select11);
			 pst.setInt(1, productId);
			 rs=pst.executeQuery();
			 if(rs.next()) {
				 System.out.println("Enter product quantity to Change:");
				 productQuantity=sc.nextInt();
				 
				 String update="update product set pquantity=? where pid=?";
				 pst=cons.prepareStatement(update);
				 pst.setInt(1, productQuantity);
				 pst.setInt(2, productId);
				 int retval=pst.executeUpdate();
				 if(retval>0) {
					 System.out.println("Successfully changed the product price");
					 displayRecords();
				 }else {
					 System.out.println("Updation Error!");
				 }
			 }else
			 {
				 System.out.println("product ID was not Found in the database");
			 }
			 break;
			 default :
				 System.out.println("Invalid choice!");
		}
		
		}

	
	

	public static void deleteRecords() throws SQLException {
		cons = JdbcConnection.getConnection(); //getting connection
		System.out.println("Enter product ID:");
		Scanner sc=new Scanner(System.in);
		productId=sc.nextInt();
		String select="select* from product where pid=?";
		pst=cons.prepareStatement(select);
		pst.setInt(1, productId);
		rs=pst.executeQuery();
		if(rs.next()) {
			String delete="delete from product where pid=?";
			pst=cons.prepareStatement(delete);
			pst.setInt(1, productId);
			int ret=pst.executeUpdate();
			if(ret>0) {
				System.out.println("Record Deleted from the database");
				displayRecords();
			}else {
				System.out.println("Deletion Error!");
			}
		}else
		{
			System.out.println("product ID was not found in the database");
		}

		
	}
	
	// user login 
	//new user login
	public static void insertNewUsers() throws IOException, SQLException {
		cons = JdbcConnection.getConnection(); 
		System.out.println("Enter the 5 digit user id:");
		userId=Integer.parseInt(br.readLine());
		System.out.println("Enter your name:");
		userName=br.readLine();
		System.out.println("Enter your 10 digit phone number:");
		userPhone=br.readLine();
		if(userPhone.length()==10) {
			
		System.out.println("Enter the password:");
		userPassword=br.readLine();
		
		//check pid exists or not
				String sel = "select * from userlogin where uid=?";
				
				pst = cons.prepareStatement(sel);
				pst.setInt(1, userId);
				rs = pst.executeQuery(); //selection use executeQuery	
				//to check id exists or not
				if(!rs.next()) { //if record is not there then go for insert
					String ins = "insert into userlogin values(?,?,?,?)";
					pst = cons.prepareStatement(ins);
					pst.setInt(1, userId);
					pst.setString(2, userName);
					pst.setString(3, userPhone);
					pst.setString(4, userPassword);
					int retval = pst.executeUpdate(); //for insert , update , delete use executeUpdate
					if(retval>0) {
						System.out.println("Registration completed Successfully");
			
					}else {
						System.out.println("Error occurred");
					}
			}
				else {
					System.out.println(userId+" already exists ");
				}	
	}else {
		System.out.println("Please enter 10 digit phone number!");	}
				
	}
	// login user performance
	public static void userMethod() throws SQLException, IOException {
		
		cons = JdbcConnection.getConnection();
		System.out.println(" -*-*-Welcome to user login-*-*-");
		System.out.println("Enter user id: ");
		 usersid=sc.nextInt();
		System.out.println("Enter password :");
		String userspassword=br.readLine();
		
		
		String select="select * from userlogin where uid=? and upass=? ";
		pst=cons.prepareStatement(select);
		pst.setInt(1, usersid);
		pst.setString(2, userspassword);
		rs=pst.executeQuery();//result set 
		if(rs.next()) {
			while(true) {
			System.out.println("----- Select the option to perform -----");
			System.out.println("1.Display products");
			System.out.println("2.Add products to the cart ");
			System.out.println("3.View cart");
			System.out.println("4.Remove cart");
			
			int carts=sc.nextInt();
			switch (carts) {
			case 1:
				JdbcOperations.displayProducts();
				break;
			case 2:
				JdbcOperations.addCart();
				break;
			case 3:
				JdbcOperations.viewCart();
				break;
			case 4:
				JdbcOperations.deleteCart();
				break;
			default:
				System.out.println("invalide choice");
				
			}
			System.out.println("Are you want to continue y/n");
			char ui=sc.next().toLowerCase().charAt(0);
			if(ui!='y') {
				System.out.println("Program is terminated!");
				break;
			}
		}
		}
			else {
			System.out.println("Incorrect user_id or password");
		}
	}

	
	// from here onwards codes for cart
	
	public static void displayProducts() throws SQLException {
		displayRecords();
		
	}
	public static void addCart() throws SQLException {
		cons = JdbcConnection.getConnection();
		float total=0;
		System.out.println("Available products are: ");
		displayRecords();
		//System.out.println("Enter your user id: ");
		//int useridd=sc.nextInt();
		int useridd=usersid;
		if( usersid==useridd) {
		
		String sel = "select * from userlogin where uid=?";
		
		pst = cons.prepareStatement(sel);
		pst.setInt(1, useridd);
		rs = pst.executeQuery(); //selection use executeQuery	
		//to check id exists or not
		if(rs.next()) { //if record is not there then go for insert
		System.out.println("Choose the product to add in your cart");
		System.out.println("Enter the product id:");
		productId=sc.nextInt();
		String selss = "select * from product where pid=?";
		
		pst = cons.prepareStatement(selss);
		pst.setInt(1, productId);
		rs = pst.executeQuery(); //selection use executeQuery	
		//to check id exists or not
		if(rs.next()) { //if record is not there then go for insert
		System.out.println("User choosen product");
		
		String sels="select * from product where pid =?";
		pst=cons.prepareStatement(sels);
		pst.setInt(1, productId);
		rs=pst.executeQuery();//result set 
		System.out.println("pid\tpname\t\tpprice\t\tpquantity");
		while(rs.next()) {
		System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getFloat(3)+"\t\t"+rs.getInt(4));
		}
		System.out.println("Enter number of quantity:");
		cartQuantity=sc.nextInt();
		String ssel="select pquantity from product where pid=?";
		pst=cons.prepareStatement(ssel);
		pst.setInt(1, productId);
		rs=pst.executeQuery();
		
				while(rs.next()) {
			if(cartQuantity <= rs.getInt("pquantity")) {
			
	sel="select pprice from product where pid=?";
	pst=cons.prepareStatement(sel);
	pst.setInt(1, productId);
	rs=pst.executeQuery();
	if(rs.next()) {
	total=cartQuantity*rs.getFloat("pprice");
		
		String insert ="insert into cart  values(?,?,?,?)";
		pst=cons.prepareStatement(insert);
		pst.setInt(1, useridd);
		pst.setInt(2, productId);
		pst.setInt(3, cartQuantity);
		pst.setFloat(4, total);
		int retval = pst.executeUpdate(); //for insert , update , delete use executeUpdate
		if(retval>0) {
			System.out.println("Product added to the cart Successfully");

		}else {
			System.out.println("Error occured");
		}
	
	}
			}else {
				System.out.println("Out of Stock");
			}
			}
		}else {
			System.out.println("Mismatching Product id !");
		}
		}
		}
		else {
			System.out.println("User ID mismaching");
		}
	}
	public static void viewCart() throws SQLException {
		cons = JdbcConnection.getConnection();
		String sel="Select * from cart where uid=?";
		pst=cons.prepareStatement(sel);
		pst.setInt(1,usersid);
		rs=pst.executeQuery();//result set 
		if(rs.next()) {
		String sells="select c.uid,c.pid,p.pname,p.pprice,c.quantity,c.totalPrice from cart c, product p where p.pid=c.pid and c.uid=?";
		pst=cons.prepareStatement(sells);
		pst.setInt(1,usersid);
		rs=pst.executeQuery();
		System.out.println("______________________________________________________________________________________________");
		System.out.println("");
		System.out.println("UserID\t\tProductID\tProductName\tProductPrice\tQuantity\tTotalPrice");
			System.out.println("______________________________________________________________________________________________");
		while(rs.next()) {
		System.out.println(rs.getInt(1)+"\t\t"+rs.getInt(2)+"\t\t"+rs.getString(3)+"\t"+rs.getFloat(4)+"\t\t"+rs.getInt(5)+"\t\t"+rs.getFloat(6));
		System.out.println("----------------------------------------------------------------------------------------------");
		System.out.println("");
				}	
		}
		else {
			System.out.println("User ID not found in the cart");
			}	
		}


	
	
	public static void deleteCart() throws SQLException {
		cons = JdbcConnection.getConnection(); //getting connection
		//System.out.println("Enter user ID:");
		//userId=sc.nextInt();
		System.out.println("Your cart details");
		viewCart();
		System.out.println("Enter the product id to remove from your cart");
		productId=sc.nextInt();
		
		String select="select * from cart where uid=? and pid=?";
		pst=cons.prepareStatement(select);
		pst.setInt(1, usersid);
		pst.setInt(2, productId);
		rs=pst.executeQuery();
		if(rs.next()) {
			String delete="delete from cart where uid=? and pid=?";
			pst=cons.prepareStatement(delete);
			pst.setInt(1, usersid);
			pst.setInt(2, productId);
			int ret=pst.executeUpdate();
			if(ret>0) {
				System.out.println("Record was removed");
			}else {
				System.out.println("Deletion Error!");
			}
		}else
		{
			System.out.println("product ID was not found!");
		}
		
		
	}
}
	
